<?php
session_start();
$conexao = new PDO('mysql:host=localhost;dbname=projetoboard','root','');

function checar()
{if(!isset($_SESSION['id'])){
    header("Location:index.php");
    exit;
}}

?>
