<?php
include 'conexao.php';
checar();
$nomeproduto = $_POST['nomeproduto'];
$linkimagem = $_POST['linkimagem'];
$linkproduto = $_POST['linkproduto'];
$preco = $_POST['preco'];
$preco = str_replace(',','.',$preco);

$sql = "INSERT INTO dados VALUES (null,'$nomeproduto','$linkimagem','$linkproduto',$preco);";
$conexao->exec($sql);
echo "<script>    window.alert('cadastrado com sucesso')</script><script> window.location.href = 'admincadastrar.php'  </script>"



?>