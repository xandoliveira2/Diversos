<?php
session_start();
include 'conexao.php';
$tipo = $_SESSION['permissao'];
if ($_SESSION['permissao'] == 1){
    
    header("Location:paginaadmin.php");
}elseif($_SESSION['permissao'] == 2){
    header("Location:paginauser.php");
  
}
else{
    echo "<script> alert('login não encontrado, faça login para ter acesso a essa página')</script><script>window.location.href = 'index.php'</script>";
}


?>