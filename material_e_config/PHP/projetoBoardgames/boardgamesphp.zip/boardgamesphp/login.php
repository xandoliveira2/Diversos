<?php        
session_start();
include 'conexao.php';
$login = $_POST['login'];
$senha = $_POST['senha'];
$sql = "SELECT login FROM login WHERE login = '$login'";
$resultado = $conexao->query($sql);
$existe = $resultado->fetch();

if ($existe){   
   
    $sql = "SELECT * FROM login WHERE login = '$login'";
    $resultado = $conexao->query($sql);
    $comparador = $resultado->fetch();
    if ($senha == $comparador['senha']) {
        $_SESSION['id'] = $comparador['id'];
        $_SESSION['permissao'] = $comparador['permissao'];

        echo "<script>alert('Acesso concedido')</script><script>window.location.href = 'identificador.php'
        </script>";
    }else{
        echo "<script>alert('Senha errada')</script><script>window.location.href = 'index.php'
        </script>";
    }
}else{

    echo "<script> alert('Não existe esse usuário, tente se cadastrar primeiro')</script>
    <script>window.location.href = 'index.php'
    </script>";
}



?>