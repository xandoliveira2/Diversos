-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30/05/2024 às 22:07
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projetoboard`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `dados`
--

CREATE TABLE `dados` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `linkimagem` mediumtext NOT NULL,
  `linkproduto` varchar(3000) NOT NULL,
  `preco` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `dados`
--

INSERT INTO `dados` (`id`, `nome`, `linkimagem`, `linkproduto`, `preco`) VALUES
(15, 'Mansions Of Madness Galápagos Jogos', 'https://m.media-amazon.com/images/I/71MXGHnaWlL._AC_SX679_.jpg', 'https://www.amazon.com.br/Gal%C3%A1pagos-Jogos-MOM001-Mansions-Madness/dp/B07CLGVK44/ref=dp-upsell-widget_d_sccl_3_2/140-0642505-3505318?pd_rd_w=ZahH1&content-id=amzn1.sym.a32fedeb-4fa5-403b-8f86-61196d9302bd&pf_rd_p=a32fedeb-4fa5-403b-8f86-61196d9302bd&pf_rd_r=Y8J1H05YAHSWHHQEAWAV&pd_rd_wg=JPwAl&pd_rd_r=c262abf9-66db-4691-854e-4e71c282aa1d&pd_rd_i=B07CLGVK44&psc=1', 769.50),
(17, 'FDP - Foi de Propósito 4, Jogo de Cartas para Rir', 'https://m.media-amazon.com/images/I/61STNdEpqQL._AC_SX679_.jpg', 'https://www.amazon.com.br/FDP-Foi-de-Prop%C3%B3sito-4/dp/B0BRNW33YG/ref=asc_df_B0BRNW33YG/?tag=googleshopp00-20&linkCode=df0&hvadid=647400986286&hvpos=&hvnetw=g&hvrand=12040040447731535250&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1031717&hvtargid=pla-2094903755492&psc=1&mcid=008192eced4b3df4994a7193ea51c223', 33.15),
(18, 'Jogo De Tabuleiro Gaming Monopoly C1009 Hasbro', 'https://http2.mlstatic.com/D_NQ_NP_2X_852178-MLA44678979171_012021-F.webp', 'https://www.mercadolivre.com.br/jogo-de-tabuleiro-gaming-monopoly-c1009-hasbro/p/MLB8872770#reco_backend=machinalis-comparator-new-brand&reco_client=pdp_comparator&reco_product_pos=2&reco_backend_type=low_level&reco_id=bc39787c-248a-4d01-9db8-847b67b096a4', 124.00),
(19, 'Jogo War Tabuleiro O Jogo da Estratégia - Grow', 'https://a-static.mlcdn.com.br/800x560/jogo-war-tabuleiro-o-jogo-da-estrategia-grow/magazineluiza/220544200/2ade64d7782d442fd4b367f1f33cf100.jpg', 'https://www.magazineluiza.com.br/jogo-war-tabuleiro-o-jogo-da-estrategia-grow/p/220544200/br/bjdt/?&seller_id=magazineluiza&utm_source=google&utm_medium=pla&utm_campaign=&partner_id=65406&gclsrc=aw.ds&gclid=Cj0KCQjwpNuyBhCuARIsANJqL9O8upipgRnqCORA2uqaPdakn3VLW2PlFtzSazKGog4Sbu0E1nod9lcaAmTBEALw_wcB', 156.79),
(22, 'Trial by Trolley, Galápagos Jogos', 'https://m.media-amazon.com/images/I/71MqCk7cUhL._AC_SX679_.jpg', 'https://www.amazon.com.br/Trial-by-Trolley-Gal%C3%A1pagos-Jogos/dp/B08RQDLZ5G?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&psc=1&smid=A1ZZFT5FULY4LN', 214.47),
(23, 'Banco Imobiliário Jogo Tabuleiro Investindo nas Ca', 'https://m.media-amazon.com/images/I/61U2Q8TWroL._AC_SX679_.jpg', 'https://www.amazon.com.br/Imobili%C3%A1rio-Tabuleiro-Investindo-Capitais-Brinquedo/dp/B07GDJVPLC?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&psc=1&smid=A1B2L2EH9ZTMCL', 49.99),
(24, 'Jogo De Tabuleiro Spin Master Games Giant Sorry! C', 'https://http2.mlstatic.com/D_NQ_NP_644255-CBT74634234305_022024-O.webp', 'https://produto.mercadolivre.com.br/MLB-4457824034-jogo-de-tabuleiro-spin-master-games-giant-sorry-criancas-cl-_JM?matt_tool=18956390&utm_source=google_shopping&utm_medium=organic', 227.57),
(25, 'Jogo De Palavras Tapple | Jogo De Tabuleiro Rápido', 'https://http2.mlstatic.com/D_NQ_NP_2X_883485-CBT73436353691_122023-F.webp', 'https://produto.mercadolivre.com.br/MLB-3531433481-jogo-de-palavras-tapple-jogo-de-tabuleiro-rapido-para-fami-_JM?matt_tool=18956390&utm_source=google_shopping&utm_medium=organic', 209.74),
(26, 'Festo! Jogo de tabuleiro - Game Brewer', 'https://i.ebayimg.com/images/g/buYAAOSwU5VmIgel/s-l960.webp', 'https://www.ebay.com/itm/395337883799?chn=ps&mkevt=1&mkcid=28', 350.63),
(27, 'jogo the game of life', 'https://photos.enjoei.com.br/jogo-the-game-of-life-100638047/1200xN/czM6Ly9waG90b3MuZW5qb2VpLmNvbS5ici9wcm9kdWN0cy83Nzg0MzkyL2I3YTIwNmJiMDE1N2E1YWEyZmYxYTkyNDY5NjJhNTgwLmpwZw', 'https://www.enjoei.com.br/p/jogo-the-game-of-life-100638047?g_campaign=google_shopping&srsltid=AfmBOorr7KLxQR9IqtNnO5IUi-kexzQUeXkPtHQN8SeJpimqCGnE19xFl1A', 155.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `login`
--

CREATE TABLE `login` (
  `login` varchar(100) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `permissao` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `login`
--

INSERT INTO `login` (`login`, `senha`, `id`, `permissao`) VALUES
('admin', 'admin', 1, 1),
('usuario1', 'usuario1', 18, 2),
('usuario2', 'usuario2', 19, 2),
('usuario3', 'usuario3', 20, 2),
('usuario4', 'usuario4', 21, 2),
('fernanda', 'fernanda', 22, 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `dados`
--
ALTER TABLE `dados`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `dados`
--
ALTER TABLE `dados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
