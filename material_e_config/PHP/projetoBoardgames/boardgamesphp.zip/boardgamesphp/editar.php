<?php
include 'conexao.php';
checar();
$id = $_POST['id'];
$sql = "SELECT * FROM dados WHERE id = '$id'";
$resultado = $conexao->query($sql);
$lista = $resultado->fetch();
?>
<!DOCTYPE html>
<html>
    <head>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    </head>
    <body>
        <form method="post" action="editar2.php">
            <label for="nome">Nome:</label> 
            <input type="text" name="nome" id="nome" value="<?=$lista['nome'];?>">
            <label for="linkimg">Link imagem:</label> 
            <input type="text" name="linkimg" id="linkimg" value="<?=$lista['linkimagem'];?>">
            <label for="linkproduto">Link produto:</label> 
            <input type="text" name="linkproduto" id="linkproduto" value="<?=$lista['linkproduto'];?>">
            <label for="preco">Preco:</label> 
            <input type="text" name="preco" id="preco" value="<?=str_replace('.',',',$lista['preco']);?>">
            <input type="hidden" name="id" value="<?=$id?>">
    	    <input type="submit" value="Atualizar">
        </form>
        <a href="paginaadmin.php"><p>Voltar</p></a>
    </body>
</html>