<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - BG</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            font-size: 10px;
            background-image: url(backgroundop.png);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
        }

        .login {
            width: 100vw;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: -40vh;
        }

        form img {
            width: 150px;
        }

        nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100vw;
            height: 6em;
            background-color: gray;
        }
        nav p:first-child{font-size: 2em;}
        nav p:nth-child(2){font-size: 2em;}

        label {
            font-size: 2.5em;
            font-family: 'Courier New', Courier, monospace;
            font-weight: 900;
            color: darkblue;
        }

        input[type=text],
        [type=password] {
            font-size: 1.5em;
            font-family: 'Courier New', Courier, monospace;
            font-weight: 700;
            padding: 2px 5px 2px 5px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <nav style="display:flex;justify-content: space-around;">
        <p>Bem vindo</p>
        <a href="cadastrar.html"><p>Cadastrar-se</p></a>


    </nav>
    <div class="login">
        <form action="login.php" method="post">
            <img src="board.png" alt="logo BG">
            <label for="login">Login</label>
            <input type="text" name="login" id="login">
            <label for="senha">Senha</label>
            <input type="password" name="senha" id="senha">
            <input type="submit" value="Login">
        </form>
    </div>

</body>

</html>