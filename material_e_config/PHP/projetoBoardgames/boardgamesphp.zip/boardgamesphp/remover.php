<?php

include 'conexao.php';
checar();
$id = $_POST['id'];

$sql = "DELETE dados FROM dados WHERE id = $id";
$conexao->exec($sql);
header("Location:paginaadmin.php");

?>