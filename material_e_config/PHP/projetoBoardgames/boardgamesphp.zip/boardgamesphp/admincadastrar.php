<?php 

include 'conexao.php';
checar();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{margin:0;padding:0;box-sizing: border-box;}
        body{display: flex;justify-content: center;align-items: center;width: 100vw;height:100vh;}
        form{display:flex;flex-direction: column;align-items: center;}
        input[type=submit]{width: fit-content;}

    </style>
</head>
<body>
        <form action="cadastrarproduto.php" method="post">
            <label for="nomeproduto">Nome:</label>
            <input type="text" name="nomeproduto" id="nomeproduto">
            <label for="linkimagem">Link para imagem:</label>
            <input type="text" name="linkimagem" id="linkimagem">
            <label for="linkproduto">Link para o produto:</label>
            <input type="text" name="linkproduto" id="linkproduto">
            <label for="preco">Preço:</label>
            <input type="text" name="preco" id="preco">
            <input type="submit" value="Cadastrar">
            <a href="paginaadmin.php">Voltar</a>

        </form>
</body>
</html>