<?php

include 'conexao.php';
checar();
if ($_SESSION['permissao']!= 2){
    header("Location:paginaadmin.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página usuário</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        html {
            font-size: 10px;
        }

        body {background-color:black;
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        nav {
            height: 6em;
            width: 100vw;
            background-color: gray;
            display: flex;
            justify-content: space-around;
            align-items: center;

        }
        .visor{width: 100vw;height: 100%;display: flex;flex-direction: column;flex-wrap: wrap;overflow-x: auto hidden;overflow-y: hidden;justify-content: center;}
        .produtos{width: 300px;height: 90%;background-color:white;border-radius: 20px;margin:0 10px 0 10px;display:flex;justify-content:center;flex-direction:column;align-items: center;justify-content: space-around;}
        .produtos img{width: 80%;height:40%;}
        .produtos button{width: 80%;height:8%;font-size: 2em;border-radius: 10px;border:solid;}
        .nome{font-size: 40px;margin:15px;}
        .preco{font-size:30px;}
        
        nav a{text-decoration: none;}
        nav p{font-size:30px;color:brown;transition: 0.5s ease-in-out;
       }
       nav p:hover{background-color: rgb(200, 200, 200);border-radius: 14px;transform: scale(1.2);transition: 0.3s ease-in-out;}
       input{margin-left:20px;}
    </style>
</head>
<body>
<nav><a href="deslogar.php"><p>Deslogar</p></a><a href="desenvolvedor.html"><p>Desenvolvedor</p></a></nav>
<div class="visor">
    <?php
    
    $sql = "SELECT * FROM dados;";
    $resultado = $conexao->query($sql);
    $lista = $resultado->fetchAll();
    foreach ($lista as $linha){
        echo '<div class="produtos">
        <img src="'.$linha['linkimagem'].'">
        <p class="nome">'.$linha['nome'].'</p>
        <p class="preco">R$'.str_replace('.',',',$linha['preco']).'</p>
        <div>
            <a href="'.$linha['linkproduto'].'" style="text-decoration: none;font-size: 3em;color:blue;" target="_BLANK"><p>Comprar</p></a>
           
        </div>  
    </div>';
    }
    ?>
    <!-- <div class="produtos">
        <img src="favicon_io (1)/android-chrome-192x192.png">
        <p class="nome"></p>
        <p class="preco">R$</p>
        <div>
            <a href="" style="text-decoration: none;font-size: 3em;color:blue;" target="_BLANK"><p>Comprar</p></a>
        </div>  
    </div> -->


    
</div>
</body>

</html>