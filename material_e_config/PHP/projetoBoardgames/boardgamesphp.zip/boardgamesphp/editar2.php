<?php
include "conexao.php";
$id = $_POST['id'];
$nome = $_POST['nome'];
$linkimg = $_POST['linkimg'];
$linkprod = $_POST['linkproduto'];
$preco = $_POST['preco'];
$novopreco = str_replace(',','.',$preco);
$sql = "update dados set nome = '$nome',linkimagem = '$linkimg', linkproduto='$linkprod',preco=$novopreco where id=$id;";
$conexao->exec($sql);
header("Location:paginaadmin.php");
?>