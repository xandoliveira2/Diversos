<?php
include "conexao.php";

$login = $_POST['login'];
$senha = $_POST['senha'];
$sql = "SELECT login FROM login WHERE login = '$login'";
$resultado = $conexao->query($sql);


if ($resultado->fetch()){       
    
    
    echo "<script>window.alert('Usuário já cadastrado')</script>";
    echo "<script>window.location.href = 'cadastrar.html'</script>";
  
} else{

    if (strlen($login) < 5){
        echo "<script>window.alert('Usuário deve haver pelo menos 5 caracteres')</script>";
        echo "<script>window.location.href = 'cadastrar.html'</script>";
    }elseif(strlen($senha) < 5) {
        echo "<script>window.alert('Senha deve haver pelo menos 5 caracteres')</script>";
        echo "<script>window.location.href = 'cadastrar.html'</script>";
    }
    else{
    $novocomandosql = "INSERT INTO login VALUES ('$login','$senha',null,2);";
    $conexao->exec($novocomandosql);
    
    
    echo "<script>window.alert('Cadastrado com sucesso')</script>";
    echo "<script>window.location.href = 'index.php'</script>";
    }
    

}



?>