package model;

public class Fornecedor {
}
