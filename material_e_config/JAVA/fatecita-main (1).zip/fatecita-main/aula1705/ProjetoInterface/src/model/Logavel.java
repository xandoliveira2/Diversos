package model;

public interface Logavel {

    void login();

    void logout();
}
