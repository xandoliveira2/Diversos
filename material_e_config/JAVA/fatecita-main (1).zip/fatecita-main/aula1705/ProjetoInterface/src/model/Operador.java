package model;

public class Operador extends Empregado{
}
