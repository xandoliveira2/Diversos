package model;

public class Empregado {
}
