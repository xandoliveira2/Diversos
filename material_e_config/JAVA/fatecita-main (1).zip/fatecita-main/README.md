# Fatec Itapira
### Repositório - Aulas Fatec DSM - Disciplina: Técnicas de Programação

Aulas do professor Marcos Roberto de Moraes (Maromo)

1) Semestre de 2024.
