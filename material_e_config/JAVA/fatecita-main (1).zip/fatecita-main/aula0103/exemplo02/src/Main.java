public class Main {
    public static void main(String[] args) {
        int opcao = 4;
        switch (opcao){
            case 1:
                System.out.println("Escolheu Skol");
                break;
            case 2:
                System.out.println("Escolheu Stela");
                break;
            case 3:
                System.out.println("Escolheu Brahma");
                break;
            default:
                System.out.println("Opcao invalida");
        }

    }
}