public class Main {
    public static void main(String[] args) {
        int tabuada = 5;
        for (int i = 1; i <= 10; i++) {
            System.out.println(tabuada + " X " + i + " = " + tabuada * i);
        }
        System.out.println("fim");
    }
}