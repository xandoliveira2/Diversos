package model;

public enum Valor {
    As, Dois, Tres,
    Quatro, Cinco, Seis,
    Sete, Oito, Nove,
    Dez, Valete, Dama,
    Reis
}
