package model;

public enum Naipe {
    Ouro,
    Espada,
    Copas,
    Paus


}
