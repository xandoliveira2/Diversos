package model;

public class Operador extends Funcionario{
    private double hora;

    public double getHora() {
        return hora;
    }

    public void setHora(double hora) {
        this.hora = hora;
    }
}
