import java.util.ArrayList;
import java.util.List;

public class GerenciarConta {

    public List<Conta> contas = new ArrayList<>();
    public static void main(String[] args) {

    }
    public void execCadastrar(){

    }
    public void execListar(){

    }
    public void execDepositar(){

    }
    public void execSacar(){

    }
    public void execAcumulado(){

    }
    public void execExibirSaldo(){

    }

}
