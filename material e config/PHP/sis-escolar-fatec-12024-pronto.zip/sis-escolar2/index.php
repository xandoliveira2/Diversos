<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Acadêmico</title>
</head>
<body>
    <h1>Sistema Acadêmico</h1>
    <form action="views/usuarios/usuario-login.php" method="post">
        <h3>Bem Vindo</h3>
        <input type="text" name="usuario" placeholder="Digite seu usuario"><br><br>
        <input type="password" name="senha" placeholder="Digite sua senha"><br><br>
        <input type="submit" value="Entrar">
    </form>
</body>
</html>