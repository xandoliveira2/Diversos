<?php
    $conexao = new PDO('mysql:host=localhost;dbname=sis-escolar', 'root', '');
?>